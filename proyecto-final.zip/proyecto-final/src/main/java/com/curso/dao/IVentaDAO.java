package com.curso.dao;

import com.curso.model.Venta;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import javax.transaction.Transactional;
import java.time.LocalDateTime;

public interface IVentaDAO extends JpaRepository<Venta, Integer> {

    @Transactional
    @Modifying
    @Query(value = "INSERT INTO venta(id_cliente, id_producto, precio_venta, fecha_venta) VALUES (:idCliente, :idProducto, :precioVenta, :fechaVenta)",
            nativeQuery = true)
    Integer registrar (@Param("idCliente") Integer idConsulta, @Param("idProducto") Integer idExamen,@Param("precioVenta") Double precioVenta, @Param("fechaVenta") LocalDateTime fechaVenta);

    @Transactional
    @Modifying
    @Query(value = "DELETE FROM venta", nativeQuery = true)
    void eliminartTodaTabla ();

}
