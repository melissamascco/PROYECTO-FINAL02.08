package com.curso.dto;

import java.time.LocalDateTime;
import java.util.List;

public class ComprobanteRequest {
    private Integer idCliente;
    private List<ProductoVen> listProducto;
    private LocalDateTime fechaVenta;

    public Integer getIdCliente() {
        return idCliente;
    }

    public void setIdCliente(Integer idCliente) {
        this.idCliente = idCliente;
    }

    public List<ProductoVen> getListProducto() {
        return listProducto;
    }

    public void setListProducto(List<ProductoVen> listProducto) {
        this.listProducto = listProducto;
    }

    public LocalDateTime getFechaVenta() {
        return fechaVenta;
    }

    public void setFechaVenta(LocalDateTime fechaVenta) {
        this.fechaVenta = fechaVenta;
    }
}
