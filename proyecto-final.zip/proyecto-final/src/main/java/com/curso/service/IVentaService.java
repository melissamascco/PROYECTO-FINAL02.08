package com.curso.service;

import com.curso.dto.ComprobanteRequest;
import com.curso.dto.ComprobanteResponse;
import com.curso.model.Venta;

public interface IVentaService extends ICRUD<Venta>{
    ComprobanteResponse registrarVentaCliente (ComprobanteRequest request);
}
