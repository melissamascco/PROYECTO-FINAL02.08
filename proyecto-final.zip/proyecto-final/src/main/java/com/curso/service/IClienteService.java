package com.curso.service;

import com.curso.model.Cliente;

public interface IClienteService extends ICRUD<Cliente>{

}
