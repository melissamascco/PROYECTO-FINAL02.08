package com.curso.service;

import com.curso.model.Producto;

public interface IProductoService extends ICRUD<Producto>{
}
