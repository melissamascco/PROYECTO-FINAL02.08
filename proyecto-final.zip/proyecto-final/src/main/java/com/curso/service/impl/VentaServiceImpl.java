package com.curso.service.impl;

import com.curso.dao.IClienteDAO;
import com.curso.dao.IProductoDAO;
import com.curso.dao.IVentaDAO;
import com.curso.dto.ComprobanteRequest;
import com.curso.dto.ComprobanteResponse;
import com.curso.dto.ProductoVen;
import com.curso.model.Cliente;
import com.curso.model.Producto;
import com.curso.model.Venta;
import com.curso.service.IVentaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class VentaServiceImpl implements IVentaService {

    @Autowired
    IVentaDAO daoVen;

    @Autowired
    IClienteDAO daoCli;

    @Autowired
    IProductoDAO daoPro;

    @Override
    public ComprobanteResponse registrarVentaCliente(ComprobanteRequest request) {

        daoVen.eliminartTodaTabla();

        //Optenemos cliente
        Optional<Cliente> opCli = daoCli.findById(request.getIdCliente());

        //Optenemos productos y registramos
        List<ProductoVen> listPro = request.getListProducto();
        List<Producto> lisrProdF = new ArrayList<>();
        Double total = 0.00;
        String codVenta = "";
        for(int i=0; i<listPro.size();i++){
            Optional<Producto> opPro = daoPro.findById(listPro.get(i).getIdProducto());
            if(opPro.get()!=null && opCli.get()!=null){

                Producto objPF = new Producto();
                objPF.setNombre(opPro.get().getNombre());
                objPF.setPrecio(opPro.get().getPrecio());
                objPF.setCantidad(listPro.get(i).getCantidad());
                Integer nuevoSto = opPro.get().getStock()-listPro.get(i).getCantidad();
                objPF.setStock(nuevoSto);
                lisrProdF.add(objPF);
                //registramos ventas
               Integer res  = daoVen.registrar(opCli.get().getIdCliente(),opPro.get().getIdProducto(),
                       opPro.get().getPrecio(),request.getFechaVenta());
               //calculando total
                Double prec = objPF.getPrecio()*listPro.get(i).getCantidad();
               total = prec +total;
               //obteniendo codigo de comprobante
               codVenta = codVenta+""+opCli.get().getIdCliente()+opPro.get().getIdProducto();
               //Actualizamos productos
                opPro.get().setStock(nuevoSto);
                daoPro.save(opPro.get());
            }
        }
        //Ordenamos y mostramos el comprovante
        ComprobanteResponse response = new ComprobanteResponse();
        response.setIdVenta(codVenta);
        response.setCliente(opCli.get());
        response.setListProducto(lisrProdF);
        response.setFechaVenta(request.getFechaVenta());
        response.setTotal(total);
        return response;
    }

    @Override
    public Venta registrar(Venta venta) {
        return daoVen.save(venta);
    }

    @Override
    public Venta actualizar(Venta venta) {
        return daoVen.save(venta);
    }

    @Override
    public int eliminar(Venta venta) {
        return 0;
    }

    @Override
    public Venta listarId(int id) {
        Optional<Venta> op = daoVen.findById(id);
        Venta obj = op.get();
        return obj;
    }

    @Override
    public List<Venta> listar() {
        return daoVen.findAll();
    }
}
