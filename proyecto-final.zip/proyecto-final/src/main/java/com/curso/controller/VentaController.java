package com.curso.controller;

import com.curso.dto.ComprobanteRequest;
import com.curso.dto.ComprobanteResponse;
import com.curso.model.Producto;
import com.curso.service.IVentaService;
import io.swagger.annotations.Api;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/venta")
@Api(value = "Servicio REST para las ventas")
public class VentaController {

    @Autowired
    private IVentaService service;

    @PostMapping(value = "/registrar", consumes = MediaType.APPLICATION_JSON_VALUE)
    public ComprobanteResponse registrar(@RequestBody ComprobanteRequest request) {
        return service.registrarVentaCliente(request);
    }
}
